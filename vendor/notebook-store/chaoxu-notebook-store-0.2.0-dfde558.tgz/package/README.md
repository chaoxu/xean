# `notebook-store`

`notebook-store` stores JSON notes in SQLite. Independent programs and people can read historical snapshots and publish changes to the current notebook. It runs on Bun and has no runtime dependencies on `xean`, Pi, or a model provider.

The notebook owns its current version. Each commit atomically records changed notes and a request receipt. An edit creates a new revision, and older snapshots remain readable. Clients editing existing notes publish against an expected version. A stale write fails without replacing another client's work.

## Use from Bun

```ts
import { Notebook } from "@chaoxu/notebook-store";

using notebook = new Notebook("knowledge.sqlite");
const base = notebook.snapshot();
const version = notebook.commit(
  base,
  { lemma: { text: "Every tree on n vertices has n−1 edges.", support: [] } },
  "add-tree-lemma",
);
console.log(notebook.read(version, ["lemma"]));
```

`snapshot()` returns the current version. A new notebook starts at version `0`.

`read(version?, ids?)` returns `{ version, notes }`, where `notes` maps IDs to JSON objects. Omitting the version reads the current snapshot. Omitting IDs reads every note in that snapshot. Missing or deleted IDs are absent from the result.

`commit(expectedVersion, changes, requestId)` returns the committed version. Each entry replaces a whole note. A `null` entry deletes it from subsequent snapshots. Repeating a request with the same request ID, base, and changes returns its original version, even after another client advances the notebook. Reusing the request ID with different input raises `ConflictError`. A stale expected version also raises `ConflictError`. The caller retains its changes and decides how to resolve the conflict.

`append(requestId, notes)` atomically adds a map of new note IDs to JSON objects at the current head and returns the committed version. Fresh requests reject previously used IDs, even if their notes were later deleted. An exact retry returns the original version even after later appends or edits. A fresh request reusing a note ID, or a retry with changed contents, raises `ConflictError`. Read the returned version to retrieve the batch's original content.

Open with `{ readonly: true }` to inspect an existing database without allowing publication. `using` closes the connection at the end of its scope.

## Use from the terminal

The CLI reads a JSON request from standard input and writes JSON to standard output:

```sh
echo '{"operation":"commit","expectedVersion":0,"changes":{"lemma":{"text":"A mathematical statement."}},"requestId":"initial"}' | bun src/cli.ts knowledge.sqlite
echo '{"operation":"read","ids":["lemma"]}' | bun src/cli.ts knowledge.sqlite
```

People can use this interface or the TypeScript API to edit notes independently of an agent campaign. Direct SQL inspection is also available. Supported edits go through `commit` so historical content and retry receipts remain consistent.

## Knowledge and execution

Note contents are opaque JSON objects. Clients define summaries, dependencies, citations, and assessments. An assessment should identify the exact note and dependency revisions it examined. Mathematical validity and acceptance remain client judgments.

SQLite WAL allows concurrent local readers and serializes short write transactions. Keep the database on local storage. Remote access needs a service beside the database. Model calls and human editing sessions happen outside database transactions.

## Package with an application

An application can install this package as a pinned dependency. Its users then install the application normally, with no separate notebook checkout or SQLite server.

For a source archive, run `bun pm pack`, ship the resulting tarball in the application's `vendor/` directory, and pin that file in its `package.json` and lockfile. Bun resolves the notebook with the application's other dependencies. The notebook remains a separate package and can also be used directly.

## Check the source checkout

Use Bun 1.4.2 or later:

```sh
bun install --frozen-lockfile
bun run check
```
