import { Database } from "bun:sqlite";
import { isDeepStrictEqual } from "node:util";

export type JsonValue =
  null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
export type Note = Record<string, JsonValue>;
type Row = { id: string; value: string | null };
type Receipt = { version: number; expectedVersion: number };

export class ConflictError extends Error {
  override name = "ConflictError";
}

function object(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function jsonCopy<T>(value: T): T {
  const encoded = JSON.stringify(value);
  const copy = encoded === undefined ? undefined : JSON.parse(encoded);
  if (encoded === undefined || !isDeepStrictEqual(value, copy))
    throw new TypeError("Value must round-trip through JSON without loss");
  return copy;
}

function decode(rows: Row[]): Record<string, Note | null> {
  return Object.fromEntries(
    rows.map(({ id, value }) => [id, JSON.parse(value ?? "null")]),
  );
}

function version(value: number) {
  if (!Number.isSafeInteger(value) || value < 0)
    throw new RangeError("Version must be a nonnegative safe integer");
}

export class Notebook {
  private db: Database;
  private readonly readOnly: boolean;

  constructor(path: string, { readonly = false }: { readonly?: boolean } = {}) {
    this.readOnly = readonly;
    this.db = new Database(path, { create: !readonly, readonly, strict: true });
    const db = this.db;
    try {
      db.exec("PRAGMA busy_timeout = 5000");
      if (!readonly) {
        db.exec("PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL");
        db.transaction(() => {
          db.exec(`
            CREATE TABLE IF NOT EXISTS commits (
              version INTEGER PRIMARY KEY,
              requestId TEXT NOT NULL UNIQUE,
              expectedVersion INTEGER NOT NULL
            ) STRICT;
            CREATE TABLE IF NOT EXISTS revisions (
              id TEXT NOT NULL,
              version INTEGER NOT NULL,
              value TEXT,
              PRIMARY KEY (id, version)
            ) STRICT;
            CREATE INDEX IF NOT EXISTS revisions_by_version ON revisions(version);
          `);
        }).immediate();
      }
      this.snapshot();
    } catch (error) {
      db.close();
      throw error;
    }
  }

  snapshot(): number {
    return this.db
      .query<{ version: number }, []>(
        "SELECT COALESCE(MAX(version), 0) AS version FROM commits",
      )
      .get()!.version;
  }

  read(
    at?: number,
    ids?: readonly string[],
  ): { version: number; notes: Record<string, Note> } {
    if (
      ids !== undefined &&
      (!Array.isArray(ids) || ids.some((id) => typeof id !== "string"))
    )
      throw new TypeError("Note IDs must be strings");
    const db = this.db;
    const current = at === undefined ? this.snapshot() : at;
    version(current);
    if (
      current !== 0 &&
      !db.query("SELECT 1 FROM commits WHERE version = ?").get(current)
    )
      throw new RangeError(`Unknown notebook version: ${current}`);
    const parameters: [number, ...string[]] =
      ids === undefined ? [current] : [current, JSON.stringify(ids)];
    const select = db.query<Row, [number, ...string[]]>(
      `
        SELECT r.id, r.value FROM revisions r JOIN (
          SELECT id, MAX(version) AS version FROM revisions
          WHERE version <= ? ${ids === undefined ? "" : "AND id IN (SELECT value FROM json_each(?))"}
          GROUP BY id
        ) latest ON r.id = latest.id AND r.version = latest.version
        WHERE r.value IS NOT NULL
        ORDER BY r.id
      `,
    );
    return {
      version: current,
      notes: decode(select.all(...parameters)) as Record<string, Note>,
    };
  }

  commit(
    expectedVersion: number,
    changes: Record<string, Note | null>,
    requestId: string,
  ): number {
    version(expectedVersion);
    return this.publish(expectedVersion, changes, requestId);
  }

  /** Append unused IDs at the current head; exact retries retain their version. */
  append(requestId: string, notes: Record<string, Note>): number {
    if (!object(notes) || Object.values(notes).some((note) => !object(note)))
      throw new TypeError("Notes must map note IDs to JSON objects");
    // commit() rejects negative bases, so the existing receipt distinguishes operations.
    return this.publish(-1, notes, requestId);
  }

  private publish(
    expectedVersion: number,
    changes: Record<string, Note | null>,
    requestId: string,
  ): number {
    if (this.readOnly) throw new Error("Notebook is read-only");
    if (typeof requestId !== "string")
      throw new TypeError("Request ID must be a string");
    if (
      !object(changes) ||
      Object.values(changes).some((note) => note !== null && !object(note))
    )
      throw new TypeError("Changes must map note IDs to JSON objects or null");
    const request = jsonCopy({ expectedVersion, changes });
    const db = this.db;
    const write = db.transaction(() => {
      const prior = db
        .query<Receipt, [string]>(
          "SELECT version, expectedVersion FROM commits WHERE requestId = ?",
        )
        .get(requestId);
      if (prior) {
        const revisions = db.query<Row, [number]>(
          "SELECT id, value FROM revisions WHERE version = ?",
        );
        const recorded = decode(revisions.all(prior.version));
        if (
          prior.expectedVersion !== expectedVersion ||
          !isDeepStrictEqual(recorded, request.changes)
        )
          throw new ConflictError("Request ID already has another value");
        return prior.version;
      }
      const head = this.snapshot();
      if (expectedVersion === -1) {
        if (
          db
            .query(
              "SELECT 1 FROM revisions WHERE id IN (SELECT value FROM json_each(?)) LIMIT 1",
            )
            .get(JSON.stringify(Object.keys(request.changes)))
        )
          throw new ConflictError("Append requires never-used note IDs");
      } else if (head !== expectedVersion)
        throw new ConflictError("Stale notebook version");
      const next = head + 1;
      version(next);
      const insert = db.query(
        "INSERT INTO revisions (id, version, value) VALUES (?, ?, ?)",
      );
      for (const [id, note] of Object.entries(request.changes))
        insert.run(id, next, note === null ? null : JSON.stringify(note));
      db.query(
        "INSERT INTO commits (version, requestId, expectedVersion) VALUES (?, ?, ?)",
      ).run(next, requestId, expectedVersion);
      return next;
    });
    return write.immediate();
  }

  [Symbol.dispose]() {
    this.db.close();
  }
}
