#!/usr/bin/env bun
import { Notebook } from "./index.ts";

const path = Bun.argv[2];
if (!path) throw new Error("Usage: notebook-store DATABASE < request.json");
const request = await Bun.stdin.json();
using notebook = new Notebook(path, {
  readonly: request.operation !== "commit",
});
let result;
switch (request.operation) {
  case "snapshot":
    result = notebook.snapshot();
    break;
  case "read":
    result = notebook.read(request.version, request.ids);
    break;
  case "commit":
    result = notebook.commit(
      request.expectedVersion,
      request.changes,
      request.requestId,
    );
    break;
  default:
    throw new Error("Expected operation: snapshot, read, or commit");
}
console.log(JSON.stringify(result));
